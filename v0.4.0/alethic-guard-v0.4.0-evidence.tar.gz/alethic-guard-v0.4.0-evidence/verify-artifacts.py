"""Read qualification artifacts independently of Guard or its Python package."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys


evidence, observer_path, checkpoint_path = (Path(value) for value in sys.argv[1:4])


def read(name):
    return json.loads((evidence / name).read_text())


checkpoint = json.loads(checkpoint_path.read_text())
workload_id = checkpoint["workload_id"]
previous = ""
for sequence, line in enumerate((evidence / "events.jsonl").read_text().splitlines(), 1):
    event = json.loads(line)
    assert event["sequence"] == sequence and event["workload_id"] == workload_id
    assert event["prev_event_hash"] == previous
    recorded = event["event_hash"]
    canonical = json.dumps(dict(event, event_hash=""), sort_keys=True,
                           ensure_ascii=False, separators=(",", ":")).encode()
    previous = "sha256:" + sha256(canonical).hexdigest()
    assert recorded == previous
assert checkpoint == {"sequence": sequence, "event_hash": previous, "workload_id": workload_id}

observed = json.loads(observer_path.read_text())
assert observed["workload_id"] == workload_id
assert observed["before"]["domain_listed"] and len(observed["before"]["qemu_pids"]) == 1
assert not observed["after"]["domain_listed"] and not observed["after"]["qemu_pids"]
stop = read("emergency-termination.json")
assert stop["id"] == workload_id
assert observed["before"]["observed_at_unix_ns"] < stop["observed_at_unix_ns"] <= (
    observed["after"]["observed_at_unix_ns"]
)
assert stop["admissions"] == stop["broker_cutoff"] == stop["shutdown"] == "VERIFIED"
unavailable = read("unavailable-observer.json")
assert unavailable["shutdown"] == "UNKNOWN" and unavailable["admissions"] == "VERIFIED"
assert "cutoff is latched" in (evidence / "restart-refused.txt").read_text()
assert read("released.json")["mode"] == "READY"
timing = read("emergency-timing.json")
assert timing["ordinary_request_pending"] and timing["elapsed_seconds"] < 5
if len(sys.argv) == 5 and sys.argv[4] == "require-queue-check":
    assert timing["ordinary_status_queued"] is True
    assert read("already-absent.json")["shutdown"] == "VERIFIED"

assert read("kvm.json")["return"] == {"enabled": True, "present": True}
assert "<interface" not in (evidence / "domain.xml").read_text()
console = (evidence / "console.txt").read_text(errors="replace")
for marker in ("unmounted_input DENIED", "direct_network DENIED", "undeclared_tool DENIED",
               "approved_delivery SUCCEEDED"):
    assert "GUARD_AGENT " + marker in console
assert any("GUARD_AGENT inference" in line and "Dana" in line for line in console.splitlines())
effect, receipt = read("approved-effect.json"), read("collector-receipt.json")
assert effect["outcome"] == "SUCCEEDED"
assert receipt["idempotency_key"] == effect["idempotency_key"]
assert receipt["payload_sha256"] == effect["payload_sha256"] == (
    sha256((evidence / "approved-record.json").read_bytes()).hexdigest()
)
with (evidence / "network-denial.pcap").open("rb") as capture:
    packets = subprocess.check_output(["tcpdump", "-n", "-r", "-"], stdin=capture,
                                      text=True, stderr=subprocess.DEVNULL)
assert sum("Flags [S]," in line for line in packets.splitlines()) == 1
assert "0 packets dropped by kernel" in (evidence / "packet-capture.log").read_text()

print(json.dumps({
    "workload_id": workload_id,
    "checkpoint_count": sequence,
    "checkpoint_head": previous,
    "independent_vm_observation": "VERIFIED",
    "kvm": "VERIFIED",
    "approved_receipt": "VERIFIED",
    "direct_guest_syns": 0,
    "ordinary_operator_pending": True,
    "queued_status": timing.get("ordinary_status_queued"),
    "shutdown_seconds": timing["elapsed_seconds"],
}, indent=2))
