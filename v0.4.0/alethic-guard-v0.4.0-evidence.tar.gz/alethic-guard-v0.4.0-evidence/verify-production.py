"""Verify published evidence without importing Guard or Alethic."""

import json
from math import ceil
from pathlib import Path
from statistics import median
import subprocess
import sys

root = Path(__file__).resolve().parent
report = root / "model-results"


def load(name):
    return json.loads((report / name).read_text())


subprocess.run([
    sys.executable, str(root / "verify-artifacts.py"), str(report),
    str(root / "observer.json"), str(root / "retained-checkpoint.json"), "require-queue-check",
], check=True)

digest = (root / "SHA256SUMS").read_text().split()[0]
build = (root / "BUILD.txt").read_text().splitlines()
commit = next(line.split()[-1] for line in build if line.startswith("Source commit "))
record = load("approved-record.json")
assert record["artifact_sha256"] == digest and record["commit"] == commit
assert record["verdict"] == "pass"
assert load("boundary-observations.json") == {"collector_receipts": 1, "serial_host_visible": True}
console = (report / "console.txt").read_text()
for marker in (
    "shell_tool DENIED", "generic_http_tool DENIED", "unapproved_fixture DENIED",
    "unapproved_destination DENIED", "unapproved_payload DENIED", "unapproved_identity DENIED",
    "local_output WRITABLE", "serial_output HOST_VISIBLE",
):
    assert "GUARD_AGENT " + marker in console, marker
assert "GUARD_PRIVATE_OUTPUT_CANARY" not in (report / "events.jsonl").read_text()

partial = load("daemon-down-unavailable-hypervisor.json")
assert partial["admissions"] == partial["broker_cutoff"] == partial["record"] == "VERIFIED"
assert partial["shutdown"] == "UNKNOWN"
network = load("daemon-down-network-observation.json")
assert network == {"namespace_absent": True, "host_link_absent": True, "deny_rules_present": True}
retry = load("daemon-down-retry.json")
assert retry["id"] == partial["id"]
assert all(retry[key] == "VERIFIED" for key in ("admissions", "broker_cutoff", "shutdown", "record"))
assert load("daemon-down-release-observation.json")["explicit_operator_release_required"]
reuse = load("broker-reuse.json")
assert reuse["same_enrollment_slot_reused"] and reuse["gateway_survived_daemon_crash"]
assert len({slot for slot, _ in reuse["fresh_gateways"]}) == 1
assert len({pid for _, pid in reuse["fresh_gateways"]}) == 4
assert reuse["recovery"]["shutdown"] == reuse["recovery"]["broker_cutoff"] == "VERIFIED"

runs = {row["case"]: row for row in map(json.loads, (root / "offline-results.jsonl").read_text().splitlines())}
direct = runs["daemon_down"]
assert direct["before"]["domain"] and len(direct["before"]["pids"]) == 1
assert direct["after"] == {"domain": False, "pids": []}
assert direct["unknown_workload_refused"] and direct["live_daemon_refused"] and direct["neighbor_unchanged"]
assert direct["response"]["shutdown"] == direct["response"]["record"] == "VERIFIED"
assert runs["startup_reconciliation"]["explicit_release_required"]
fault = runs["fence_storage_unavailable"]
assert fault["after"] == {"domain": False, "pids": []}
assert fault["response"]["admissions"] == "UNKNOWN" and fault["response"]["shutdown"] == "VERIFIED"

summary = {}
for case in ("idle", "concurrent", "cpu_contention"):
    row = runs[case]
    samples = row["samples"]
    assert len(samples) == row["n"] == row["verified"] == 100
    for item in samples:
        assert item["before"]["domain"] and len(item["before"]["pids"]) == 1
        assert item["after"] == {"domain": False, "pids": []}
        assert all(item["guard"][key] == "VERIFIED" for key in ("admissions", "broker_cutoff", "shutdown"))
        assert 0 < item["latency_ms"] < 5000
    times = sorted(item["latency_ms"] for item in samples)
    assert row["median_ms"] == median(times)
    assert row["p95_ms"] == times[ceil(len(times) * .95) - 1]
    assert row["p99_ms"] == times[ceil(len(times) * .99) - 1]
    assert row["worst_ms"] == times[-1]
    assert row["failed_or_unverified"] == row["unknown"] == row["timeouts"] == row["over_5s"] == 0
    summary[case] = {key: value for key, value in row.items() if key not in {"case", "samples"}}

print(json.dumps({"artifact_sha256": digest, "source_commit": commit, "shutdown_results": summary}, indent=2))
