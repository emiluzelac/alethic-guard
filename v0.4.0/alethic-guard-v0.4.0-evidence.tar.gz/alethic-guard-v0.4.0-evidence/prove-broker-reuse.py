"""Mediated slot reuse and process-crash recovery on the disposable systemd guest."""

import json
from pathlib import Path
import re
import subprocess
from time import monotonic, sleep

ROOT = Path("/opt/alethic-guard/current")
CLI = ROOT / "venv/bin/alethic-guard"
DAEMON = ROOT / "bin/alethic-guardd"
SOCKET = Path("/run/alethic-guard/operator.sock")
UNIT = "alethic-guardd.service"
CONTROLLER = "alethic-guard-controller.service"


def ctl(*args):
    subprocess.run(["systemctl", *args], check=True)


def call(*args):
    return json.loads(subprocess.check_output(args, text=True, timeout=40))


def workload(command, *options):
    return call(CLI, "workload", command, *options)


def socket_ready():
    deadline = monotonic() + 15
    while monotonic() < deadline:
        try:
            result = workload("status", "00000000-0000-0000-0000-000000000000")
        except subprocess.CalledProcessError:
            sleep(.1)
        else:
            assert result["mode"] == "UNMANAGED"
            return
    raise RuntimeError("Guard operator socket unavailable")


def namespace_and_gateway():
    rows = subprocess.check_output(["ip", "netns", "list"], text=True).splitlines()
    found = [row.split()[0] for row in rows if re.match(r"aleg\d+\b", row)]
    if not found:
        return None
    assert len(found) == 1, found
    namespace = found[0]
    deadline = monotonic() + 4
    while monotonic() < deadline:
        pids = subprocess.check_output(["ip", "netns", "pids", namespace], text=True).split()
        for pid in pids:
            path = Path(f"/proc/{pid}/exe")
            try:
                executable = path.readlink()
            except FileNotFoundError:
                continue
            if executable.name == "alethic-guard-gateway":
                return namespace, int(pid)
        sleep(.02)
    raise RuntimeError("no bound gateway process")


def main():
    ctl("start", UNIT)
    try:
        socket_ready()
        id = workload("create", "--profile", "broker-lab", "--image", "minimal.qcow2",
                      "--input", "local-agent.img")["enrollment"]["id"]
        assert workload("start", id)["mode"] == "RUNNING"
        first = namespace_and_gateway()
        assert first is not None
        assert workload("pause", id)["mode"] == "PAUSED"
        assert namespace_and_gateway() is None
        assert workload("resume", id)["mode"] == "RUNNING"
        second = namespace_and_gateway()
        assert second is not None and second[0] == first[0] and second[1] != first[1]
        assert workload("terminate", id)["shutdown"] == "VERIFIED"
        assert namespace_and_gateway() is None
        assert workload("release", id)["mode"] == "READY"
        assert workload("start", id)["mode"] == "RUNNING"
        third = namespace_and_gateway()
        assert third is not None and third[0] == first[0] and third[1] != second[1]
        assert workload("terminate", id)["shutdown"] == "VERIFIED"
        assert workload("release", id)["mode"] == "READY"
    finally:
        ctl("stop", UNIT)

    SOCKET.parent.mkdir(mode=0o711, exist_ok=True)
    process = subprocess.Popen([
        DAEMON, "/var/lib/alethic-guard", "/etc/alethic-guard/policies",
        str(SOCKET), "/etc/alethic-guard/collector.json",
    ])
    try:
        socket_ready()
        assert workload("start", id)["mode"] == "RUNNING"
        live = namespace_and_gateway()
        assert live is not None and live[0] == first[0]
        process.kill()
        process.wait(timeout=5)
        assert namespace_and_gateway() == live
        recovered = call(DAEMON, "--recover", id)
        assert all(recovered[key] == "VERIFIED" for key in (
            "admissions", "broker_cutoff", "shutdown", "record",
        ))
        assert namespace_and_gateway() is None
        assert id not in subprocess.check_output(
            ["virsh", "list", "--all", "--uuid"], text=True,
        ).split()
    finally:
        if process.poll() is None:
            process.kill()
            process.wait(timeout=5)
        ctl("stop", CONTROLLER)
    print(json.dumps({
        "same_enrollment_slot_reused": True, "fresh_gateways": [first, second, third, live],
        "gateway_survived_daemon_crash": True, "recovery": recovered,
    }))


if __name__ == "__main__":
    main()
