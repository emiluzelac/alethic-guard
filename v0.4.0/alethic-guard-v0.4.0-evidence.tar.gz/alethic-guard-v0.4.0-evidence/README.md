# Alethic Guard v0.4.0 qualification

The tests ran the checksummed Linux x86-64 archive built from commit `5e30638e64736badc1986eedf165755274386472`. The collector delivered the approved record for this archive digest and commit and returned a matching receipt.

The installation and mediated tests ran on Ubuntu 24.04.5 x86-64 with nested KVM and Linux `6.8.0-147-generic`. The repeated shutdown and offline recovery tests ran on physical Intel KVM in disposable Ubuntu 24.04 userspace under Linux `7.0.0-42-generic`. The physical host test used a private network namespace, a container AppArmor override for namespace mounts, and two CPU cores of capacity. Both environments used libvirt `10.0.0-2ubuntu8.19`, QEMU `1:8.2.2+ds-0ubuntu1.18`, glibc `2.39`, and SeaBIOS `1.16.3-2`.

The offline suite recorded 100 shutdowns per workload condition with an idle queue, a running neighbor, and CPU contention. Timing uses a small firmware-only KVM fixture. The direct host-recovery case used the approved Ubuntu guest and an active neighboring VM. Each verified observation includes both the libvirt domain and QEMU process readback. The runs test the measured hardware and operations.

The mediated systemd suite checked a pinned SmolLM2 model with synthetic prompts, one scoped collector receipt, fixed tool and output cases, and emergency shutdown while two ordinary operator requests were pending. A separate observer sampled VM state. The capture records one calibrated host SYN and zero direct guest SYNs. Serial reveals guest-provided output to the host. The journal checkpoint was retained off-host.

With both installed Guard services stopped and libvirt temporarily unavailable, host recovery verified removal of the broker namespace and veth while reporting shutdown as unknown. Recovery verified shutdown after libvirt returned and required operator release after restart. Repeated mediated launches reused the enrollment's slot and created fresh gateway processes. A daemon crash left a gateway alive, and direct recovery retired that gateway and verified VM shutdown. Startup stopped a surviving VM before rejecting unsafe launch directory permissions.

The v0.3.0 upgrade preserved the test enrollment, fence, approved policy, and existing journal checkpoint. Separate read-only agent sessions assessed the source and verified fixes for the release findings. A separate agent verified the archive checksum and triggered a live installation and daemon-down recovery replay on a second Ubuntu KVM guest. See `independent-live-replay.log` for that replay.

Run the verifier with Python 3 and tcpdump. It checks the journal hash chain, receipt, observer records, tool denials, raw repeated-run measurements, and recovery evidence.

```sh
python3 verify-production.py
```

The approved Ubuntu image SHA-256 is `89b9f9c17ddf521b31504b8fee5c74dc2bdbb9f4f990500043a8a811a13bc71a`. The SmolLM2 weights SHA-256 is `2e8040ceae7815abe0dcb3540b9995eaa0d2ca9e797d0a635ae4433c68c2d`. The measured NoCloud seed SHA-256 is `748533e2a148b0da150b33276e0537ccc43be8b171c909804ba86c97f603e717`. [Reproduction procedures](https://github.com/emiluzelac/alethic-guard/tree/v0.4.0/tests/lab)
